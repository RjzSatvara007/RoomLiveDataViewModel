package com.rjz.RoomJavaExample;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final WordViewModel wordViewModel = ViewModelProviders.of(this).get(WordViewModel.class);
        final TextView textView = findViewById(R.id.tvTest);

        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText test = findViewById(R.id.edtName);
                wordViewModel.insert(new Student(test.getText().toString()));
            }
        });

        findViewById(R.id.btnFind).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText test = findViewById(R.id.edtFind);
                Student student = wordViewModel.findStudent(Integer.parseInt(test.getText().toString()));
                if (student != null)
                    Toast.makeText(MainActivity.this, student.name + " is name.", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "No records found.", Toast.LENGTH_SHORT).show();
            }
        });

        if (wordViewModel == null) {
            Log.e("!_@_@_", "-------view model value is null-----------");
        } else {
            wordViewModel.getAllStudent().observe(this, new Observer<List<Student>>() {
                @Override
                public void onChanged(@Nullable List<Student> studentList) {
                    textView.setText("");
                    for (Student student : studentList) {
                        textView.append(student.id + " " + student.name + "\n");
                    }
                }
            });
        }
    }
}
