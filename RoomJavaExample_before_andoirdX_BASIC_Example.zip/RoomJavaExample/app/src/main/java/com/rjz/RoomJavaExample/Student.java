package com.rjz.RoomJavaExample;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

// 1 of 5
@Entity(tableName = "student_table")
public class Student {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    public int id = 0;

    @NonNull
    @ColumnInfo(name = "name")
    public String name;

    public Student(String name) {
        this.name = name;
    }
}
