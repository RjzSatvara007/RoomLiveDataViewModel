package com.rjz.RoomJavaExample;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

// 3 of 5
@Database(entities = {Student.class}, version = 1, exportSchema = false)
public abstract class StudentRoomDataBase extends RoomDatabase {

    private static StudentRoomDataBase INSTANCE;

    static StudentRoomDataBase getInstance(final Context context) {
        if (INSTANCE == null) {
           /* synchronized (StudentRoomDataBase.class)*/ {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            StudentRoomDataBase.class, "stud_database")
                            .allowMainThreadQueries()
                            // TODO NOTE for .allowMainThreadQueries() 1B of 2B
                            // if not want to make query on main thread then
                            // remove this line. you have to use Asynktask for it.
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    public abstract StudentDao getStudentDao();
}
