package com.rjz.RoomJavaExample;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;

// 2 of 5

@Dao
public interface StudentDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Student word);

    @Query("Select * from student_table where id= :id")
    Student findStudent(int id);

    @Query("Select * from student_table")
    LiveData<List<Student>> getAllStudent();

}
